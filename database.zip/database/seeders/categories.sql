INSERT INTO `categories` (`name`, `status`)
VALUES ('Electrónicos', 1),
       ('Propiedades', 1),
       ('Vacaciones', 1),
       ('Gastronomía', 1),
       ('Entretenimiento', 1),
       ('Autos', 1),
       ('Botes', 1);
